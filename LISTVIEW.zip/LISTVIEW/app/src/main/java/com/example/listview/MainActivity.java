package com.example.listview;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {

    ListView listView;

    String[] name = {"Java","Python","JQuery","Ruby","Swift","Apache"};

    Integer[] image = {R.drawable.java,R.drawable.python,R.drawable.jquery,R.drawable.ruby,R.drawable.swift,R.drawable.apache};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.list);

        MyListAdapter myListAdapter = new MyListAdapter(this,name,image);
        listView.setAdapter(myListAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(MainActivity.this,DetailedScreen.class);

                intent.putExtra("image",image[i]);
                intent.putExtra("name",name[i]);

                startActivity(intent);
            }
        });


    }
}