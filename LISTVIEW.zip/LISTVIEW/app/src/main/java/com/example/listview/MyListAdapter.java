package com.example.listview;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class MyListAdapter extends ArrayAdapter<String> {

    private String[] name;
    private Integer[] image;
    private Activity context;

   public MyListAdapter(Activity context, String[] name, Integer[] image){
       super(context,R.layout.mylist,name);

       this.context = context;
       this.name = name;
       this.image = image;

   }
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        LayoutInflater inflater = context.getLayoutInflater();

        View rowView = inflater.inflate(R.layout.mylist,null,true);

        TextView tv = rowView.findViewById(R.id.textView);
        ImageView imageView = rowView.findViewById(R.id.imageView);

        tv.setText(name[position]);
        imageView.setImageResource(image[position]);

       return rowView;
    }
}
