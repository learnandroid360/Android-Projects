package com.example.listview;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class DetailedScreen extends AppCompatActivity {

    ImageView img;
    TextView t1,t2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detailed_screen);

        img = findViewById(R.id.d_img);
        t1 = findViewById(R.id.d_name);
        t2 = findViewById(R.id.d_year);

        Intent i = this.getIntent();

        if (i != null){

            String name = i.getStringExtra("name");
            Integer image = i.getIntExtra("image",R.drawable.java);

            img.setImageResource(image);
            t1.setText(name);
        }




    }
}